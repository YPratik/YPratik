import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import MeetingsList from './pages/MeetingsList';
import NewMeeting from './pages/NewMeeting';
import Home from './pages/Home';
import Dashboard from './pages/Dashboard';
import Setup from './pages/Setup';
import './App.css';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Navigate to="/meetings" replace />} />
        <Route path="/home" element={<Home />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/setup" element={<Setup />} />
        <Route path="/meetings" element={<MeetingsList />} />
        <Route path="/meetings/new" element={<NewMeeting />} />
      </Routes>
    </Router>
  );
}

export default App;