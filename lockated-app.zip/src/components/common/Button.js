import React from 'react';
import './Button.css';
import { FaPlus } from 'react-icons/fa';

const Button = ({ 
  children, 
  variant = 'primary', 
  type = 'button', 
  onClick, 
  icon 
}) => {
  return (
    <button 
      type={type} 
      className={`btn btn-${variant}`} 
      onClick={onClick}
    >
      {icon && <span className="btn-icon">{icon}</span>}
      {children}
    </button>
  );
};

export default Button;