import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaPlus, FaCalendarAlt, FaClock, FaUsers } from 'react-icons/fa';

import {
  Select,
  ToggleSwitch,
  Button,
  Input,
  Textarea
} from '../FormElements';

import MeetingPoint from './MeetingPoint';
import './MeetingForm.css';

const MeetingForm = () => {
  const navigate = useNavigate();
  const [isInternal, setIsInternal] = useState(true);
  const [participants, setParticipants] = useState([{ id: 1, name: '' }]);
  
  // Meeting details form state
  const [meetingForm, setMeetingForm] = useState({
    id: '',
    title: '',
    date: '',
    time: '',
    type: '',
    mode: '',
    organizer: '',
    status: 'Active',
    participants: [],
    points: [{ description: '', raisedBy: '', status: '', convertToTask: false }]
  });
  
  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Initialize with a generated Meeting ID on component mount
  useEffect(() => {
    generateMeetingId();
  }, []);

  const generateMeetingId = () => {
    const prefix = 'MOM';
    const randomId = Math.floor(1000 + Math.random() * 9000);
    const meetingId = `${prefix}-${randomId}`;
    setMeetingForm(prev => ({ ...prev, id: meetingId }));
  };

  const handleToggleChange = () => {
    setIsInternal(!isInternal);
  };

  const handleAddPoint = () => {
    const newPoints = [...meetingForm.points, { description: '', raisedBy: '', status: '', convertToTask: false }];
    setMeetingForm({ ...meetingForm, points: newPoints });
  };

  const handlePointChange = (index, field, value) => {
    const updatedPoints = [...meetingForm.points];
    updatedPoints[index] = { ...updatedPoints[index], [field]: value };
    setMeetingForm({ ...meetingForm, points: updatedPoints });
  };

  const handleRemovePoint = (index) => {
    const updatedPoints = [...meetingForm.points];
    updatedPoints.splice(index, 1);
    setMeetingForm({ ...meetingForm, points: updatedPoints });
  };

  const addParticipant = () => {
    setParticipants([...participants, { id: participants.length + 1, name: '' }]);
  };

  const removeParticipant = (id) => {
    if (participants.length > 1) {
      setParticipants(participants.filter(p => p.id !== id));
    }
  };

  const handleParticipantChange = (id, value) => {
    const updatedParticipants = participants.map(p => 
      p.id === id ? { ...p, name: value } : p
    );
    setParticipants(updatedParticipants);
    
    // Update participants count in form data
    const validParticipants = updatedParticipants.filter(p => p.name.trim() !== '');
    setMeetingForm({ ...meetingForm, participants: validParticipants });
  };

  const validateForm = () => {
    const errors = {};
    
    if (!meetingForm.title.trim()) errors.title = 'Meeting title is required';
    if (!meetingForm.date) errors.date = 'Meeting date is required';
    if (!meetingForm.time) errors.time = 'Meeting time is required';
    if (!meetingForm.type) errors.type = 'Meeting type is required';
    if (!meetingForm.mode) errors.mode = 'Meeting mode is required';
    if (!meetingForm.organizer) errors.organizer = 'Organizer is required';
    
    // Check if at least one point has a description
    const hasValidPoint = meetingForm.points.some(point => point.description.trim() !== '');
    if (!hasValidPoint) errors.points = 'At least one meeting point with description is required';
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    if (validateForm()) {
      // Calculate counts for the table
      const participantsCount = participants.filter(p => p.name.trim() !== '').length;
      const actionItemsCount = meetingForm.points.filter(p => p.convertToTask).length;
      
      // Prepare meeting data for storage
      const meetingData = {
        ...meetingForm,
        participants: participantsCount,
        agendaItems: meetingForm.points.length,
        actionItems: actionItemsCount
      };
      
      // Get existing meetings from localStorage
      const existingMeetings = JSON.parse(localStorage.getItem('meetings') || '[]');
      
      // Add new meeting to the array
      const updatedMeetings = [meetingData, ...existingMeetings];
      
      // Save back to localStorage
      localStorage.setItem('meetings', JSON.stringify(updatedMeetings));
      
      // Redirect back to meetings list
      navigate('/meetings');
    } else {
      setIsSubmitting(false);
      // Scroll to the first error
      const firstErrorField = Object.keys(formErrors)[0];
      const element = document.querySelector(`[name="${firstErrorField}"]`);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  };

  // Meeting type options
  const meetingTypeOptions = [
    { value: 'status', label: 'Status Update' },
    { value: 'planning', label: 'Planning' },
    { value: 'review', label: 'Review' },
    { value: 'retrospective', label: 'Retrospective' },
    { value: 'other', label: 'Other' }
  ];

  // Meeting mode options
  const meetingModeOptions = [
    { value: 'in-person', label: 'In Person' }, 
    { value: 'virtual', label: 'Virtual' },
    { value: 'hybrid', label: 'Hybrid' }
  ];

  // Sample users for demonstration
  const userOptions = [
    { value: 'john', label: 'John Doe' },
    { value: 'jane', label: 'Jane Smith' },
    { value: 'sohail', label: 'Sohail Ansari' },
    { value: 'ryan', label: 'Ryan Johnson' },
    { value: 'emily', label: 'Emily Wilson' }
  ];

  return (
    <div className="meeting-form-container">
      <h2>New Minutes Of Meeting</h2>
      
      <form onSubmit={handleFormSubmit}>
        <div className="form-section">
          <div className="form-section-title">Meeting Details</div>
          
          <div className="form-row">
            <div className="form-col">
              <Input
                label="Meeting ID"
                type="text"
                value={meetingForm.id}
                onChange={(e) => setMeetingForm({ ...meetingForm, id: e.target.value })}
                disabled
                name="id"
              />
              {formErrors.id && <div className="error-message">{formErrors.id}</div>}
            </div>
            
            <div className="form-col">
              <Input
                label="Meeting Title"
                placeholder="Enter meeting title"
                value={meetingForm.title}
                onChange={(e) => setMeetingForm({ ...meetingForm, title: e.target.value })}
                name="title"
              />
              {formErrors.title && <div className="error-message">{formErrors.title}</div>}
            </div>
            
            <div className="form-col">
              <Input
                label="Meeting Date"
                type="date"
                placeholder="Select meeting date"
                value={meetingForm.date}
                onChange={(e) => setMeetingForm({ ...meetingForm, date: e.target.value })}
                name="date"
                icon={<FaCalendarAlt />}
              />
              {formErrors.date && <div className="error-message">{formErrors.date}</div>}
            </div>
          </div>
          
          <div className="form-row">
            <div className="form-col">
              <Input
                label="Meeting Time"
                type="time"
                placeholder="Select meeting time"
                value={meetingForm.time}
                onChange={(e) => setMeetingForm({ ...meetingForm, time: e.target.value })}
                name="time"
                icon={<FaClock />}
              />
              {formErrors.time && <div className="error-message">{formErrors.time}</div>}
            </div>
            
            <div className="form-col">
              <Select
                label="Meeting Type"
                placeholder="Select meeting type"
                options={meetingTypeOptions}
                value={meetingForm.type}
                onChange={(e) => setMeetingForm({ ...meetingForm, type: e.target.value })}
                name="type"
              />
              {formErrors.type && <div className="error-message">{formErrors.type}</div>}
            </div>
            
            <div className="form-col">
              <Select
                label="Meeting Mode"
                placeholder="Select meeting mode"
                options={meetingModeOptions}
                value={meetingForm.mode}
                onChange={(e) => setMeetingForm({ ...meetingForm, mode: e.target.value })}
                name="mode"
              />
              {formErrors.mode && <div className="error-message">{formErrors.mode}</div>}
            </div>
          </div>
          
          <div className="form-row">
            <div className="form-col">
              <Select
                label="Organizer"
                placeholder="Select organizer"
                options={userOptions}
                value={meetingForm.organizer}
                onChange={(e) => setMeetingForm({ ...meetingForm, organizer: e.target.value })}
                name="organizer"
              />
              {formErrors.organizer && <div className="error-message">{formErrors.organizer}</div>}
            </div>
          </div>
        </div>
        
        <div className="section-divider"></div>
        
        <div className="form-section">
          <div className="form-section-title">Participants</div>
          
          <div className="toggle-section">
            <ToggleSwitch 
              isOn={isInternal} 
              handleToggle={handleToggleChange} 
              onLabel="External" 
              offLabel="Internal" 
            />
          </div>
          
          {participants.map((participant, index) => (
            <div className="form-row participant-row" key={participant.id}>
              <div className="form-col">
                <Select
                  label={isInternal ? "Internal User" : "External User"}
                  placeholder={`Select ${isInternal ? 'internal' : 'external'} user`}
                  options={userOptions}
                  value={participant.name}
                  onChange={(e) => handleParticipantChange(participant.id, e.target.value)}
                  name={`participant-${participant.id}`}
                />
              </div>
              
              <div className="form-col">
                <div className="participant-actions">
                  {index === participants.length - 1 ? (
                    <Button variant="outline" onClick={addParticipant} icon={<FaPlus />}>
                      Add More
                    </Button>
                  ) : (
                    <Button 
                      variant="outline-danger" 
                      onClick={() => removeParticipant(participant.id)}
                    >
                      Remove
                    </Button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="section-divider"></div>
        
        <div className="form-section">
          <div className="form-section-title">Discussion Points</div>
          {formErrors.points && <div className="error-message section-error">{formErrors.points}</div>}
          
          {meetingForm.points.map((point, index) => (
            <MeetingPoint 
              key={index}
              pointNumber={index + 1}
              onChange={(field, value) => handlePointChange(index, field, value)}
              onRemove={() => handleRemovePoint(index)}
              data={point}
              userOptions={userOptions}
              isLastPoint={index === meetingForm.points.length - 1}
            />
          ))}
          
          <div className="add-point-container">
            <Button variant="outline" onClick={handleAddPoint} icon={<FaPlus />}>
              Add New Point
            </Button>
          </div>
        </div>
        
        <div className="section-divider"></div>
        
        <div className="form-section">
          <div className="form-section-title">Attachments</div>
          
          <div className="documents-section">
            <p className="no-docs">No Documents Attached</p>
            <p className="doc-instructions">Drop or attach relevant documents here</p>
            
            <label className="file-upload-label">
              <input type="file" multiple className="file-input" />
              <span className="btn btn-outline">Attach Files</span>
            </label>
          </div>
        </div>
        
        <div className="section-divider"></div>
        
        <div className="form-actions">
          <Button 
            type="button" 
            variant="outline" 
            onClick={() => navigate('/meetings')}
          >
            Cancel
          </Button>
          <Button 
            type="submit" 
            variant="primary"
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Creating...' : 'Create Meeting'}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default MeetingForm;