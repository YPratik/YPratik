import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaPlus, FaChevronDown, FaChevronUp } from 'react-icons/fa';
import './MeetingList.css';

const MeetingList = () => {
  const navigate = useNavigate();
  const [meetings, setMeetings] = useState([]);
  const [expandedId, setExpandedId] = useState(null);
  
  useEffect(() => {
    // Load meetings from localStorage if available
    const savedMeetings = localStorage.getItem('meetings');
    if (savedMeetings) {
      setMeetings(JSON.parse(savedMeetings));
    } else {
      // Sample data as fallback
      setMeetings([
        {
          id: 'PR-001',
          title: 'Project 1',
          date: '2025-05-14',
          status: 'Active',
          organizer: 'Sohail Ansari',
          mode: 'In Person',
          participants: 6,
          agendaItems: 10,
          actionItems: 5
        }
      ]);
    }
  }, []);

  const handleNewMeeting = () => {
    navigate('/meetings/new');
  };

  const toggleDropdown = (id) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const getFormattedDate = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  const getStatusStyle = (status) => {
    switch(status?.toLowerCase()) {
      case 'active':
        return { backgroundColor: '#6AC259' };
      case 'completed':
        return { backgroundColor: '#3498db' };
      case 'pending':
        return { backgroundColor: '#f39c12' };
      default:
        return { backgroundColor: '#6AC259' };
    }
  };

  return (
    <div className="meeting-list">
      <div className="meeting-list-header">
        <h2>Minutes Of Meeting</h2>
        <button className="btn btn-primary new-mom-btn" onClick={handleNewMeeting}>
          <FaPlus /> New MoM
        </button>
      </div>
      <div className="meeting-table-container">
        <table className="meeting-table">
          <thead>
            <tr>
              <th>MoM id</th>
              <th>Minutes Title</th>
              <th>Date Of Meeting</th>
              <th>Organizer</th>
              <th>Meeting Mode</th>
              <th>Participants</th>
              <th>Agenda Items</th>
              <th>Action Items</th>
            </tr>
          </thead>
          <tbody>
            {meetings.map(meeting => (
              <tr key={meeting.id} onClick={() => navigate(`/meetings/${meeting.id}`)} className="meeting-row">
                <td>{meeting.id}</td>
                <td>{meeting.title}</td>
                <td>
                  <div 
                    className="status-dropdown"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleDropdown(meeting.id);
                    }}
                  >
                    <div className="active-status" style={getStatusStyle(meeting.status)}>
                      {meeting.status || 'Active'}
                      <span className="arrow-icon">
                        {expandedId === meeting.id ? <FaChevronUp /> : <FaChevronDown />}
                      </span>
                    </div>
                    
                    {expandedId === meeting.id && (
                      <div className="status-options">
                        <div className="status-option" onClick={() => {
                          const updatedMeetings = meetings.map(m => 
                            m.id === meeting.id ? {...m, status: 'Active'} : m
                          );
                          setMeetings(updatedMeetings);
                          localStorage.setItem('meetings', JSON.stringify(updatedMeetings));
                        }}>Active</div>
                        <div className="status-option" onClick={() => {
                          const updatedMeetings = meetings.map(m => 
                            m.id === meeting.id ? {...m, status: 'Pending'} : m
                          );
                          setMeetings(updatedMeetings);
                          localStorage.setItem('meetings', JSON.stringify(updatedMeetings));
                        }}>Pending</div>
                        <div className="status-option" onClick={() => {
                          const updatedMeetings = meetings.map(m => 
                            m.id === meeting.id ? {...m, status: 'Completed'} : m
                          );
                          setMeetings(updatedMeetings);
                          localStorage.setItem('meetings', JSON.stringify(updatedMeetings));
                        }}>Completed</div>
                      </div>
                    )}
                  </div>
                  <div className="meeting-date">{getFormattedDate(meeting.date)}</div>
                </td>
                <td>{meeting.organizer}</td>
                <td>{meeting.mode}</td>
                <td>{meeting.participants}</td>
                <td>{meeting.points?.length || 0}</td>
                <td>{meeting.points?.filter(p => p.convertToTask).length || 0}</td>
              </tr>
            ))}
            {meetings.length === 0 && (
              <tr>
                <td colSpan="8" className="no-meetings">No meetings found. Create a new meeting to get started.</td>
              </tr>
            )}
            {meetings.length > 0 && meetings.length < 10 && Array(10 - meetings.length).fill(0).map((_, index) => (
              <tr key={`empty-${index}`} className="empty-row">
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MeetingList;