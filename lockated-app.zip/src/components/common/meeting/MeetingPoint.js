import React from 'react';
import { FaTrash } from 'react-icons/fa';
import { Textarea, Select, Checkbox, Button } from '../FormElements';
import './MeetingPoint.css';

const MeetingPoint = ({ 
  pointNumber, 
  onChange, 
  data, 
  onRemove, 
  users = [], 
  statusOptions = [],
  canRemove = false 
}) => {
  return (
    <div className="meeting-point">
      <div className="meeting-point-header">
        <h3>Point {pointNumber}</h3>
        {canRemove && (
          <Button 
            variant="danger-text" 
            onClick={onRemove}
            type="button"
            icon={<FaTrash />}
          >
            Remove
          </Button>
        )}
      </div>
      
      <div className="meeting-point-content">
        <div className="meeting-point-col">
          <Textarea
            label="Description"
            placeholder="Enter description here..."
            value={data.description}
            onChange={(e) => onChange('description', e.target.value)}
          />
          
          <div className="task-checkbox">
            <Checkbox
              label="Convert to task"
              checked={data.convertToTask}
              onChange={(e) => onChange('convertToTask', e.target.checked)}
            />
          </div>
          
          {data.convertToTask && (
            <div className="task-assignee">
              <Select
                label="Assign To"
                placeholder="Select assignee"
                options={users}
                value={data.assignee}
                onChange={(e) => onChange('assignee', e.target.value)}
              />
            </div>
          )}
        </div>
        
        <div className="meeting-point-col">
          <Select
            label="Raised By"
            placeholder="Select user"
            options={users}
            value={data.raisedBy}
            onChange={(e) => onChange('raisedBy', e.target.value)}
          />
          
          <Select
            label="Status"
            placeholder="Select status"
            options={statusOptions}
            value={data.status}
            onChange={(e) => onChange('status', e.target.value)}
          />
        </div>
      </div>
    </div>
  );
};

export default MeetingPoint;