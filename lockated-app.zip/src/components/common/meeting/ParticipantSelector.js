import React from 'react';
import { FaPlus, FaTrash } from 'react-icons/fa';
import { Select, Button } from '../FormElements';
import './ParticipantSelector.css';

const ParticipantSelector = ({ 
  isInternal,
  index,
  participant,
  onUserChange,
  onRoleChange,
  onAddParticipant,
  onRemoveParticipant,
  userOptions,
  roleOptions,
  isLast,
  canRemove
}) => {
  return (
    <div className="participant-selector">
      <div className="participant-row">
        <div className="participant-col">
          <Select
            label={isInternal ? "Internal User" : "External User"}
            placeholder={`Select ${isInternal ? 'internal' : 'external'} user`}
            options={userOptions}
            value={participant.user}
            onChange={(e) => onUserChange(index, e.target.value)}
          />
        </div>
        
        <div className="participant-col">
          <Select
            label="Role"
            placeholder="Select role"
            options={roleOptions}
            value={participant.role}
            onChange={(e) => onRoleChange(index, e.target.value)}
          />
        </div>
        
        <div className="participant-col participant-actions">
          <div className="action-buttons">
            {isLast && (
              <Button variant="outline" onClick={onAddParticipant} icon={<FaPlus />} type="button">
                Add More
              </Button>
            )}
            
            {canRemove && (
              <Button 
                variant="danger-outline" 
                onClick={() => onRemoveParticipant(index)} 
                icon={<FaTrash />}
                type="button"
              >
                Remove
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ParticipantSelector;