import React from 'react';
import TopNavbar from '../components/common/TopNavbar';
import Sidebar from '../components/common/Sidebar';
import './Dashboard.css';

const Dashboard = () => {
  return (
    <div className="app-container">
      <TopNavbar />
      <div className="content-container">
        <Sidebar />
        <div className="main-content">
          <div className="dashboard-content">
            <h1>Dashboard</h1>
            <p>Dashboard content goes here.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;