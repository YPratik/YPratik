import React from 'react';
import TopNavbar from '../components/common/TopNavbar';
import Sidebar from '../components/common/Sidebar';
import './Home.css';

const Home = () => {
  return (
    <div className="app-container">
      <TopNavbar />
      <div className="content-container">
        <Sidebar />
        <div className="main-content">
          <div className="home-content">
            <h1>Welcome to Lockated</h1>
            <p>Home page content goes here.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;