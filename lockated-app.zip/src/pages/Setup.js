import React from 'react';
import TopNavbar from '../components/common/TopNavbar';
import Sidebar from '../components/common/Sidebar';
import './Setup.css';

const Setup = () => {
  return (
    <div className="app-container">
      <TopNavbar />
      <div className="content-container">
        <Sidebar />
        <div className="main-content">
          <div className="setup-content">
            <h1>Setup</h1>
            <p>Setup content goes here.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Setup;